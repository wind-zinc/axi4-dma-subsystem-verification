/*
 * Directed activation for the seven stability assertions that were vacuous
 * in the normal regression.  Ready outputs are forced low only where the
 * current DUT has no software-visible way to create that backpressure.
 */
class dma_sva_activation_seq extends dma_base_seq;

    `uvm_object_utils(dma_sva_activation_seq)

    virtual dma_mem_ctrl_if mem_vif;

    localparam string AXIL_AWREADY_PATH =
        "tb_uvm_top.dut.dma_desc_manager_inst.axil_reg_if_inst.axil_reg_if_wr_inst.s_axil_awready";
    localparam string AXIL_AWVALID_PATH =
        "tb_uvm_top.dut.s_axil_awvalid";
    localparam string AXIL_WREADY_PATH =
        "tb_uvm_top.dut.dma_desc_manager_inst.axil_reg_if_inst.axil_reg_if_wr_inst.s_axil_wready";
    localparam string AXIL_WVALID_PATH =
        "tb_uvm_top.dut.s_axil_wvalid";
    localparam string AXIL_ARREADY_PATH =
        "tb_uvm_top.dut.dma_desc_manager_inst.axil_reg_if_inst.axil_reg_if_rd_inst.s_axil_arready";
    localparam string AXIL_ARVALID_PATH =
        "tb_uvm_top.dut.s_axil_arvalid";

    localparam string READ_DESC_READY_PATH =
        "tb_uvm_top.dut.axi_dma_inst.axi_dma_rd_inst.s_axis_read_desc_ready_reg";
    localparam string READ_DESC_VALID_PATH =
        "tb_uvm_top.dut.read_desc_valid";
    localparam string WRITE_DESC_READY_PATH =
        "tb_uvm_top.dut.axi_dma_inst.axi_dma_wr_inst.s_axis_write_desc_ready_reg";
    localparam string WRITE_DESC_VALID_PATH =
        "tb_uvm_top.dut.write_desc_valid";

    function new(string name = "dma_sva_activation_seq");
        super.new(name);
    endfunction

    virtual function void require_paths();
        if (!uvm_hdl_check_path(AXIL_AWREADY_PATH) ||
            !uvm_hdl_check_path(AXIL_AWVALID_PATH) ||
            !uvm_hdl_check_path(AXIL_WREADY_PATH) ||
            !uvm_hdl_check_path(AXIL_WVALID_PATH) ||
            !uvm_hdl_check_path(AXIL_ARREADY_PATH) ||
            !uvm_hdl_check_path(AXIL_ARVALID_PATH) ||
            !uvm_hdl_check_path(READ_DESC_READY_PATH) ||
            !uvm_hdl_check_path(READ_DESC_VALID_PATH) ||
            !uvm_hdl_check_path(WRITE_DESC_READY_PATH) ||
            !uvm_hdl_check_path(WRITE_DESC_VALID_PATH))
            `uvm_fatal("SVA_PATH",
                "one or more SVA activation backdoor paths are unavailable")
    endfunction

    virtual task force_low(input string path);
        uvm_hdl_data_t value;
        value = '0;
        if (!uvm_hdl_force(path, value))
            `uvm_fatal("SVA_FORCE",
                $sformatf("uvm_hdl_force failed for %s", path))
    endtask

    virtual task release_path(input string path);
        if (!uvm_hdl_release(path))
            `uvm_fatal("SVA_RELEASE",
                $sformatf("uvm_hdl_release failed for %s", path))
    endtask

    virtual task wait_high(input string path);
        uvm_hdl_data_t value;

        repeat (2000) begin
            @(negedge mem_vif.clk);
            if (!uvm_hdl_read(path, value))
                `uvm_fatal("SVA_READ",
                    $sformatf("uvm_hdl_read failed for %s", path))
            if (value[0])
                return;
        end

        `uvm_fatal("SVA_TIMEOUT",
            $sformatf("%s did not assert", path))
    endtask

    /* Hold a forced READY low for several complete sampled cycles after its
     * matching VALID appears, then restore the real DUT driver. */
    virtual task release_after_stall(
        input string ready_path,
        input string valid_path,
        input int unsigned cycles = 4
    );
        wait_high(valid_path);
        repeat (cycles) @(posedge mem_vif.clk);
        @(negedge mem_vif.clk);
        release_path(ready_path);
    endtask

    virtual task exercise_axil_request_stability();
        bit [31:0] read_value;

        force_low(AXIL_AWREADY_PATH);
        fork
            write_reg(REG_TAG, 32'h0000_0011);
            release_after_stall(AXIL_AWREADY_PATH,
                                AXIL_AWVALID_PATH);
        join

        force_low(AXIL_WREADY_PATH);
        fork
            write_reg(REG_TAG, 32'h0000_0022);
            release_after_stall(AXIL_WREADY_PATH,
                                AXIL_WVALID_PATH);
        join

        force_low(AXIL_ARREADY_PATH);
        fork
            read_reg(REG_STATUS, read_value);
            release_after_stall(AXIL_ARREADY_PATH,
                                AXIL_ARVALID_PATH);
        join
    endtask

    virtual task write_with_bready_delay(
        input bit [AXIL_ADDR_WIDTH-1:0] addr,
        input bit [AXIL_DATA_WIDTH-1:0] data,
        input int unsigned delay_cycles
    );
        axil_item tr;

        tr = axil_item::type_id::create("delayed_b_tr");
        start_item(tr);
        tr.op             = AXIL_WRITE;
        tr.addr           = addr;
        tr.wdata          = data;
        tr.wstrb          = '1;
        tr.bready_delay   = delay_cycles;
        tr.rready_delay   = 0;
        finish_item(tr);

        if (!tr.is_okay())
            `uvm_error("SVA_DELAYED_B",
                $sformatf("write failed: %s", tr.convert2string()))
    endtask

    virtual task read_with_rready_delay(
        input bit [AXIL_ADDR_WIDTH-1:0] addr,
        input int unsigned delay_cycles
    );
        axil_item tr;

        tr = axil_item::type_id::create("delayed_r_tr");
        start_item(tr);
        tr.op             = AXIL_READ;
        tr.addr           = addr;
        tr.wdata          = '0;
        tr.wstrb          = '0;
        tr.bready_delay   = 0;
        tr.rready_delay   = delay_cycles;
        finish_item(tr);

        if (!tr.is_okay())
            `uvm_error("SVA_DELAYED_R",
                $sformatf("read failed: %s", tr.convert2string()))
    endtask

    virtual task exercise_descriptor_stability();
        force_low(WRITE_DESC_READY_PATH);
        fork
            submit_descriptor(16'h1000, 16'h8000, 20'd128, 8'hd0);
            release_after_stall(WRITE_DESC_READY_PATH,
                                WRITE_DESC_VALID_PATH);
        join
        check_and_pop_completion(8'hd0, 20'd128);

        force_low(READ_DESC_READY_PATH);
        fork
            submit_descriptor(16'h1200, 16'h8200, 20'd128, 8'hd1);
            release_after_stall(READ_DESC_READY_PATH,
                                READ_DESC_VALID_PATH);
        join
        check_and_pop_completion(8'hd1, 20'd128);
    endtask

    virtual task body();
        if (mem_vif == null)
            `uvm_fatal("NO_MEM_VIF", "memory-control interface is null")

        require_paths();
        mem_vif.clear_all();
        write_reg(REG_CONTROL, 32'h0000_0001);

        exercise_axil_request_stability();

        /* These legal response delays activate ap_axil_b_stable and
         * ap_axil_r_stable without any hierarchical force. */
        write_with_bready_delay(REG_TAG, 32'h0000_0033, 8);
        read_with_rready_delay(REG_STATUS, 8);

        exercise_descriptor_stability();
        mem_vif.clear_all();
    endtask

endclass
