class dma_sva_activation_test extends dma_mem_test_base;

    `uvm_component_utils(dma_sva_activation_test)

    function new(string name = "dma_sva_activation_test",
                 uvm_component parent = null);
        super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
        dma_sva_activation_seq seq;

        phase.raise_objection(this);
        seq = dma_sva_activation_seq::type_id::create("seq");
        seq.mem_vif = mem_vif;
        seq.start(env.axil_agt.sqr);
        #100ns;
        phase.drop_objection(this);
    endtask

endclass
